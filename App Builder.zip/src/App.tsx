import { useState, useEffect, useRef, useCallback, useMemo } from 'react'
import mohiPhoto from '@/imports/WhatsApp_Image_2026-07-22_at_2.36.33_AM.jpeg'
import hafsaPhoto from '@/imports/WhatsApp_Image_2026-07-22_at_2.36.34_AM.jpeg'
import mem1 from '@/imports/WhatsApp_Image_2026-07-22_at_2.36.34_AM__3_.jpeg'
import mem2 from '@/imports/WhatsApp_Image_2026-07-22_at_2.36.35_AM__1_.jpeg'
import mem3 from '@/imports/WhatsApp_Image_2026-07-22_at_2.36.35_AM.jpeg'

const RG = '#B76E79'
const RGL = '#D9A0AA'
const WW = '#F7EDF1'
const MUTED = '#7A7073'

// ── Particles ──────────────────────────────────────────────────────────────
interface Particle { id: number; x: number; size: number; speed: number; opacity: number; drift: number }
function Particles() {
  const [pts] = useState<Particle[]>(() =>
    Array.from({ length: 28 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      size: 1 + Math.random() * 1.5,
      speed: 18 + Math.random() * 22,
      opacity: 0.06 + Math.random() * 0.14,
      drift: -1.5 + Math.random() * 3,
    }))
  )
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {pts.map(p => (
        <div key={p.id} style={{
          position: 'absolute', left: `${p.x}%`, top: '110%',
          width: p.size, height: p.size, borderRadius: '50%',
          background: RG, opacity: p.opacity,
          animation: `riseUp ${p.speed}s linear ${-Math.random() * p.speed}s infinite`,
          '--d': `${p.drift}vw`,
        } as React.CSSProperties} />
      ))}
    </div>
  )
}

// ── Scroll Progress ─────────────────────────────────────────────────────────
function ScrollProgress() {
  const [pct, setPct] = useState(0)
  useEffect(() => {
    const fn = () => {
      const d = document.documentElement
      setPct(d.scrollTop / (d.scrollHeight - d.clientHeight))
    }
    window.addEventListener('scroll', fn, { passive: true })
    return () => window.removeEventListener('scroll', fn)
  }, [])
  return (
    <div className="fixed top-0 left-0 right-0 z-50 h-[2px]" style={{ background: `${RG}22` }}>
      <div className="h-full" style={{ width: `${pct * 100}%`, background: `linear-gradient(90deg,${RG},${RGL})`, boxShadow: `0 0 6px ${RG}`, transition: 'width 0.1s linear' }} />
    </div>
  )
}

// ── Music Player ────────────────────────────────────────────────────────────
function fmt(s: number) {
  if (!isFinite(s)) return '0:00'
  const m = Math.floor(s / 60), sec = Math.floor(s % 60)
  return `${m}:${sec.toString().padStart(2, '0')}`
}

function MusicPlayer() {
  const audioRef = useRef<HTMLAudioElement>(null)
  const [playing, setPlaying] = useState(false)
  const [muted, setMuted] = useState(false)
  const [current, setCurrent] = useState(0)
  const [duration, setDuration] = useState(0)
  const [hasFile, setHasFile] = useState(true)

  useEffect(() => {
    const a = audioRef.current; if (!a) return
    const onTime = () => setCurrent(a.currentTime)
    const onMeta = () => setDuration(a.duration)
    const onErr = () => setHasFile(false)
    a.addEventListener('timeupdate', onTime)
    a.addEventListener('loadedmetadata', onMeta)
    a.addEventListener('error', onErr)
    return () => { a.removeEventListener('timeupdate', onTime); a.removeEventListener('loadedmetadata', onMeta); a.removeEventListener('error', onErr) }
  }, [])

  const toggle = () => {
    const a = audioRef.current; if (!a || !hasFile) return
    if (playing) { a.pause(); setPlaying(false) } else { a.play().catch(() => setHasFile(false)); setPlaying(true) }
  }
  const toggleMute = () => {
    const a = audioRef.current; if (!a) return
    a.muted = !a.muted; setMuted(a.muted)
  }
  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    const a = audioRef.current; if (!a || !duration) return
    const rect = e.currentTarget.getBoundingClientRect()
    a.currentTime = ((e.clientX - rect.left) / rect.width) * duration
  }

  const progress = duration ? (current / duration) * 100 : 0

  // animated bars (3 bars, staggered)
  const bars = useMemo(() => [
    { h: [3, 10, 5, 14, 7], dur: 0.6 },
    { h: [10, 4, 14, 3, 12], dur: 0.8 },
    { h: [5, 13, 3, 10, 6], dur: 0.7 },
  ], [])

  return (
    <div style={{
      position: 'fixed', bottom: 20, right: 20, zIndex: 50,
      background: 'rgba(4,4,4,0.95)', border: `1px solid ${RG}55`,
      backdropFilter: 'blur(16px)', width: 200, borderRadius: 2,
      boxShadow: `0 4px 32px rgba(0,0,0,0.6), 0 0 0 1px ${RG}22`,
      overflow: 'hidden',
    }}>
      <audio ref={audioRef} loop src="/music/background.mp3" preload="metadata" />

      {/* Header row */}
      <div style={{ padding: '10px 12px 8px', display: 'flex', alignItems: 'center', gap: 8 }}>
        {/* Waveform bars */}
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 2, height: 16, flexShrink: 0 }}>
          {bars.map((bar, bi) => (
            <div key={bi} style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', height: 16, gap: 1 }}>
              {[0].map(() => (
                <div key={0} style={{
                  width: 2, borderRadius: 1,
                  background: playing ? RG : `${RG}44`,
                  height: playing ? undefined : 4,
                  animation: playing ? `wave${bi} ${bar.dur}s ease-in-out infinite alternate` : 'none',
                }} />
              ))}
            </div>
          ))}
        </div>

        {/* Song label */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontFamily: 'Inter,sans-serif', fontSize: 9, letterSpacing: '0.2em', textTransform: 'uppercase', color: playing ? RGL : '#5a5055', lineHeight: 1.2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {hasFile ? (playing ? 'Now Playing' : 'Our Song') : 'Add music file'}
          </p>
          {duration > 0 && (
            <p style={{ fontFamily: 'Inter,sans-serif', fontSize: 9, color: '#3d3538', marginTop: 2 }}>
              {fmt(current)} / {fmt(duration)}
            </p>
          )}
        </div>

        {/* Controls */}
        <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
          <button onClick={toggle}
            style={{ width: 24, height: 24, border: `1px solid ${playing ? RG : RG + '44'}`, background: playing ? `${RG}22` : 'transparent', borderRadius: 1, color: playing ? RGL : WW, fontSize: 9, display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.3s', flexShrink: 0 }}
            title={playing ? 'Pause' : 'Play'}>
            {playing ? '⏸' : '▶'}
          </button>
          <button onClick={toggleMute}
            style={{ width: 24, height: 24, border: `1px solid ${RG}33`, background: 'transparent', borderRadius: 1, color: muted ? '#3d3538' : `${RG}cc`, fontSize: 9, display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.3s', flexShrink: 0 }}
            title={muted ? 'Unmute' : 'Mute'}>
            {muted ? '🔇' : '🔊'}
          </button>
        </div>
      </div>

      {/* Progress bar */}
      <div onClick={seek} style={{ height: 2, background: `${RG}22`, cursor: 'pointer', position: 'relative' }}>
        <div style={{ height: '100%', width: `${progress}%`, background: `linear-gradient(90deg,${RG},${RGL})`, transition: 'width 0.3s linear', boxShadow: playing ? `0 0 6px ${RG}` : 'none' }} />
      </div>

      <style>{`
        @keyframes wave0 { from{height:3px} to{height:14px} }
        @keyframes wave1 { from{height:10px} to{height:4px} }
        @keyframes wave2 { from{height:5px} to{height:13px} }
      `}</style>
    </div>
  )
}

// ── Lightbox ────────────────────────────────────────────────────────────────
interface LBProps { images: string[]; index: number; onClose: () => void; onNav: (i: number) => void }
function Lightbox({ images, index, onClose, onNav }: LBProps) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
      if (e.key === 'ArrowRight') onNav((index + 1) % images.length)
      if (e.key === 'ArrowLeft') onNav((index - 1 + images.length) % images.length)
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [index, images.length, onClose, onNav])
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center"
      style={{ background: 'rgba(0,0,0,0.96)', backdropFilter: 'blur(8px)' }} onClick={onClose}>
      <button onClick={onClose} style={{ position: 'absolute', top: 20, right: 24, color: RGL, background: 'none', border: 'none', fontSize: 22, cursor: 'pointer' }}>✕</button>
      {images.length > 1 && <>
        <button onClick={e => { e.stopPropagation(); onNav((index - 1 + images.length) % images.length) }}
          style={{ position: 'absolute', left: 12, color: RG, background: 'none', border: 'none', fontSize: 36, cursor: 'pointer' }}>‹</button>
        <button onClick={e => { e.stopPropagation(); onNav((index + 1) % images.length) }}
          style={{ position: 'absolute', right: 12, color: RG, background: 'none', border: 'none', fontSize: 36, cursor: 'pointer' }}>›</button>
      </>}
      <img src={images[index]} alt="Memory" onClick={e => e.stopPropagation()}
        style={{ maxWidth: '90vw', maxHeight: '90vh', objectFit: 'contain', border: `1px solid ${RG}44` }} />
    </div>
  )
}

// ── Reveal ──────────────────────────────────────────────────────────────────
function useReveal(threshold = 0.12) {
  const ref = useRef<HTMLDivElement>(null)
  const [vis, setVis] = useState(false)
  useEffect(() => {
    const el = ref.current; if (!el) return
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setVis(true); obs.disconnect() } }, { threshold })
    obs.observe(el); return () => obs.disconnect()
  }, [threshold])
  return { ref, vis }
}
function Reveal({ children, delay = 0, className = '' }: { children: React.ReactNode; delay?: number; className?: string }) {
  const { ref, vis } = useReveal()
  return (
    <div ref={ref} className={className}
      style={{ opacity: vis ? 1 : 0, transform: vis ? 'none' : 'translateY(20px)', transition: `opacity 0.8s ease ${delay}ms, transform 0.8s ease ${delay}ms` }}>
      {children}
    </div>
  )
}

// ── Chat bubble ─────────────────────────────────────────────────────────────
function ChatLine({ text, side, delay }: { text: string; side: 'left' | 'right'; delay: number }) {
  const { ref, vis } = useReveal(0.1)
  return (
    <div ref={ref} style={{
      display: 'flex', justifyContent: side === 'right' ? 'flex-end' : 'flex-start',
      opacity: vis ? 1 : 0, transform: vis ? 'none' : `translateX(${side === 'right' ? 20 : -20}px)`,
      transition: `opacity 0.7s ease ${delay}ms, transform 0.7s ease ${delay}ms`,
    }}>
      <span style={{
        padding: '10px 18px', borderRadius: 18,
        fontFamily: 'Inter,sans-serif', fontSize: 14, letterSpacing: '0.01em',
        background: side === 'right' ? `${RG}22` : 'rgba(255,255,255,0.05)',
        border: `1px solid ${side === 'right' ? RG + '55' : 'rgba(255,255,255,0.1)'}`,
        color: side === 'right' ? RGL : WW, maxWidth: 240,
      }}>{text}</span>
    </div>
  )
}

// ── Primitives ───────────────────────────────────────────────────────────────
function Divider() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '36px auto', maxWidth: 320 }}>
      <div style={{ flex: 1, height: 1, background: `linear-gradient(to right, transparent, ${RG}55)` }} />
      <span style={{ color: RG, fontSize: 8, letterSpacing: '0.3em' }}>◆</span>
      <div style={{ flex: 1, height: 1, background: `linear-gradient(to left, transparent, ${RG}55)` }} />
    </div>
  )
}

const Eyebrow = ({ children }: { children: React.ReactNode }) => (
  <p style={{ textAlign: 'center', fontSize: 10, letterSpacing: '0.32em', textTransform: 'uppercase', color: RG, fontFamily: 'Inter,sans-serif', marginBottom: 12 }}>{children}</p>
)

function H({ children, size = 2 }: { children: React.ReactNode; size?: 1 | 2 | 3 }) {
  const fs = { 1: 'clamp(2.4rem,8vw,5.5rem)', 2: 'clamp(1.7rem,5vw,3rem)', 3: 'clamp(1.3rem,4vw,2.2rem)' }[size]
  return (
    <h2 style={{ textAlign: 'center', fontSize: fs, lineHeight: 1.15, fontFamily: "'Playfair Display',serif", color: WW, fontWeight: 400, marginBottom: 10 }}>
      {children}
    </h2>
  )
}

function P({ children, italic, accent, small }: { children: React.ReactNode; italic?: boolean; accent?: boolean; small?: boolean }) {
  return (
    <p style={{
      textAlign: 'center', fontFamily: 'Inter,sans-serif',
      fontSize: small ? 12 : 14, fontWeight: 300, lineHeight: 1.7,
      color: accent ? RGL : MUTED,
      fontStyle: italic ? 'italic' : 'normal',
    }}>{children}</p>
  )
}

function Quote({ children }: { children: React.ReactNode }) {
  return (
    <blockquote style={{
      textAlign: 'center', margin: '28px auto', padding: '0 16px', maxWidth: 560,
      fontFamily: "'Cormorant Garamond',serif", fontSize: 'clamp(1.1rem,3vw,1.5rem)',
      lineHeight: 1.5, fontStyle: 'italic', color: RGL,
    }}>"{children}"</blockquote>
  )
}

// ── Content container ────────────────────────────────────────────────────────
function Container({ children, wide }: { children: React.ReactNode; wide?: boolean }) {
  return (
    <div style={{ maxWidth: wide ? 860 : 560, margin: '0 auto', padding: '0 24px', width: '100%' }}>
      {children}
    </div>
  )
}

// ── Section ──────────────────────────────────────────────────────────────────
function Section({ id, children, dark }: { id?: string; children: React.ReactNode; dark?: boolean }) {
  return (
    <section id={id} style={{ position: 'relative', zIndex: 10, padding: '56px 0', background: dark ? '#020202' : 'transparent' }}>
      {children}
    </section>
  )
}

// ── Cinematic line group (tighter spacing for poem-style lines) ───────────────
function Lines({ lines, accent }: { lines: string[]; accent?: boolean }) {
  const { ref, vis } = useReveal()
  return (
    <div ref={ref} style={{ opacity: vis ? 1 : 0, transform: vis ? 'none' : 'translateY(16px)', transition: 'opacity 0.9s ease, transform 0.9s ease' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, padding: '0 24px' }}>
        {lines.map((l, i) => <P key={i} italic={accent}>{l}</P>)}
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
export default function App() {
  const [lightbox, setLightbox] = useState<{ images: string[]; index: number } | null>(null)
  const memPhotos = [mem1, mem2, mem3]
  const openLB = useCallback((imgs: string[], i: number) => setLightbox({ images: imgs, index: i }), [])
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })

  return (
    <div style={{ background: '#050505', minHeight: '100vh', color: WW }}>
      <style>{`
        @keyframes riseUp {
          0%   { transform:translateY(0) translateX(0); opacity:0 }
          10%  { opacity:1 }
          90%  { opacity:1 }
          100% { transform:translateY(-110vh) translateX(var(--d,0)); opacity:0 }
        }
        @keyframes glow { 0%,100%{opacity:.35} 50%{opacity:.8} }
        @keyframes floatY { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
        @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:none} }
        *{box-sizing:border-box;margin:0;padding:0}
        html{scroll-behavior:smooth}
        body{background:#050505}
        ::selection{background:${RG}44;color:${WW}}
        ::-webkit-scrollbar{width:3px}
        ::-webkit-scrollbar-track{background:#0a0a0a}
        ::-webkit-scrollbar-thumb{background:${RG}55;border-radius:4px}
        button{cursor:pointer}
      `}</style>

      <Particles />
      <ScrollProgress />
      <MusicPlayer />

      {lightbox && (
        <Lightbox images={lightbox.images} index={lightbox.index}
          onClose={() => setLightbox(null)}
          onNav={i => setLightbox(l => l ? { ...l, index: i } : null)} />
      )}

      {/* ── HERO ─────────────────────────────────────────────────────────── */}
      <section id="hero" style={{
        position: 'relative', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', textAlign: 'center',
        minHeight: '100vh', padding: '80px 24px', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none',
          background: `radial-gradient(ellipse 65% 55% at 50% 55%, ${RG}14 0%, transparent 70%)`,
          animation: 'glow 7s ease-in-out infinite' }} />

        <div style={{ position: 'relative', zIndex: 1, animation: 'fadeUp 1.6s ease both', maxWidth: 700, width: '100%' }}>
          <p style={{ fontSize: 10, letterSpacing: '0.35em', textTransform: 'uppercase', color: RG, fontFamily: 'Inter,sans-serif', marginBottom: 32 }}>
            A Story Written Across Borders
          </p>
          <h1 style={{ fontFamily: "'Playfair Display',serif", color: WW, fontWeight: 400, fontSize: 'clamp(2rem,9vw,5.5rem)', lineHeight: 1.1, marginBottom: 10 }}>
            Syed Mohi Alam
          </h1>
          <p style={{ color: RG, fontFamily: "'Playfair Display',serif", fontSize: 'clamp(1.4rem,5vw,3rem)', margin: '8px 0' }}>×</p>
          <h1 style={{ fontFamily: "'Playfair Display',serif", color: WW, fontWeight: 400, fontSize: 'clamp(2rem,9vw,5.5rem)', lineHeight: 1.1, marginBottom: 18 }}>
            Hafsa Ameer
          </h1>
          <p style={{ fontFamily: "'Cormorant Garamond',serif", color: MUTED, fontSize: 'clamp(0.95rem,3vw,1.2rem)', fontStyle: 'italic', marginBottom: 10 }}>
            Two countries. Two hearts. One beautiful story. ✨
          </p>
          <p style={{ fontSize: 10, letterSpacing: '0.3em', color: RG, fontFamily: 'Inter,sans-serif', textTransform: 'uppercase', marginBottom: 32 }}>
            25 April 2025
          </p>
          <button onClick={() => scrollTo('strangers')}
            style={{ padding: '12px 32px', border: `1px solid ${RG}`, color: RGL, background: 'transparent', fontFamily: 'Inter,sans-serif', fontSize: 10, letterSpacing: '0.25em', textTransform: 'uppercase', transition: 'background 0.4s' }}
            onMouseEnter={e => { (e.target as HTMLElement).style.background = `${RG}18` }}
            onMouseLeave={e => { (e.target as HTMLElement).style.background = 'transparent' }}>
            Open Our Story ♡
          </button>
        </div>

        <div style={{ position: 'absolute', bottom: 32, left: '50%', transform: 'translateX(-50%)', animation: 'floatY 3s ease-in-out infinite' }}>
          <div style={{ width: 1, height: 40, background: `linear-gradient(to bottom, transparent, ${RG}88)`, margin: '0 auto' }} />
        </div>
      </section>

      {/* ── TWO STRANGERS ───────────────────────────────────────────────── */}
      <Section id="strangers">
        <Container>
          <Reveal>
            <Eyebrow>Before We Became Us</Eyebrow>
            <H size={2}>Once upon a time, we were just two strangers. 🤍</H>
          </Reveal>
        </Container>

        <Reveal delay={150}>
          <div style={{ display: 'flex', flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'flex-start', gap: 24, margin: '32px auto 24px', padding: '0 24px', maxWidth: 700 }}>
            {/* Mohi LEFT */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, flex: '1 1 220px', maxWidth: 280 }}>
              <div style={{ border: `1px solid ${RG}55`, background: '#0B090A', boxShadow: `0 0 32px ${RG}1a`, width: '100%' }}>
                <img src={mohiPhoto} alt="Syed Mohi Alam"
                  style={{ display: 'block', width: '100%', height: 'auto', objectFit: 'contain' }} />
              </div>
              <p style={{ fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase', color: RG, fontFamily: 'Inter,sans-serif', textAlign: 'center' }}>
                Syed Mohi Alam — India 🇮🇳
              </p>
            </div>

            {/* × */}
            <div style={{ display: 'flex', alignItems: 'center', color: RG, fontFamily: "'Playfair Display',serif", fontSize: '2rem', alignSelf: 'center', flexShrink: 0 }}>×</div>

            {/* Hafsa RIGHT */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, flex: '1 1 220px', maxWidth: 280 }}>
              <div style={{ border: `1px solid ${RG}55`, background: '#0B090A', boxShadow: `0 0 32px ${RG}1a`, width: '100%' }}>
                <img src={hafsaPhoto} alt="Hafsa Ameer"
                  style={{ display: 'block', width: '100%', height: 'auto', objectFit: 'contain' }} />
              </div>
              <p style={{ fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase', color: RG, fontFamily: 'Inter,sans-serif', textAlign: 'center' }}>
                Hafsa Ameer — Pakistan 🇵🇰
              </p>
            </div>
          </div>
        </Reveal>

        <Container>
          <Reveal delay={300}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <P>Two strangers. Two different countries. Two completely different lives.</P>
              <P>Neither of us knew that one simple conversation would become the beginning of something so important.</P>
            </div>
            <Divider />
          </Reveal>
        </Container>
      </Section>

      {/* ── THE FIRST "HI" ──────────────────────────────────────────────── */}
      <Section id="first-hi">
        <Container>
          <Reveal>
            <Eyebrow>The First Conversation</Eyebrow>
            <H size={2}>25 April 2025</H>
            <P>The day our story quietly began.</P>
          </Reveal>

          <div style={{ margin: '28px auto', maxWidth: 280, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <ChatLine text="Hi." side="right" delay={0} />
            <ChatLine text="Hi." side="left" delay={300} />
            <ChatLine text="Where are you from?" side="right" delay={700} />
            <ChatLine text="Pakistan 🇵🇰" side="left" delay={1100} />
            <ChatLine text="India 🇮🇳" side="right" delay={1400} />
          </div>

          <Reveal delay={200}>
            <P>That was it. Just a simple question. 🥹</P>
            <P>But neither of us knew those few words would become the beginning of our story.</P>
          </Reveal>

          <Reveal delay={350}>
            <div style={{ margin: '28px auto', padding: '20px 32px', border: `1px solid ${RG}33`, background: `${RG}08`, textAlign: 'center', display: 'inline-block', width: '100%' }}>
              <p style={{ fontSize: 22 }}>🇮🇳</p>
              <p style={{ fontSize: 10, letterSpacing: '0.3em', textTransform: 'uppercase', color: RG, fontFamily: 'Inter,sans-serif', marginTop: 6, marginBottom: 10 }}>India</p>
              <div style={{ width: 1, height: 24, background: `${RG}66`, margin: '0 auto' }} />
              <p style={{ color: RG, fontSize: '1.1rem', margin: '4px 0' }}>×</p>
              <div style={{ width: 1, height: 24, background: `${RG}66`, margin: '0 auto' }} />
              <p style={{ fontSize: 10, letterSpacing: '0.3em', textTransform: 'uppercase', color: RG, fontFamily: 'Inter,sans-serif', marginTop: 10, marginBottom: 6 }}>Pakistan</p>
              <p style={{ fontSize: 22 }}>🇵🇰</p>
            </div>
          </Reveal>
          <Divider />
        </Container>
      </Section>

      {/* ── JOURNEY BEGAN ───────────────────────────────────────────────── */}
      <Section id="journey">
        <Container>
          <Reveal>
            <Eyebrow>The Story Unfolds</Eyebrow>
            <H size={2}>And Then... Our Journey Began</H>
          </Reveal>

          <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 18 }}>
            <Lines lines={[
              'One conversation became another.',
              'One message became hundreds.',
              'Days turned into nights filled with conversations.',
            ]} />
            <Lines lines={[
              'Slowly, I started waiting for your messages.',
              'Slowly, your happiness started becoming important to me.',
              'Slowly, your presence became a part of my everyday life.',
            ]} />
            <Lines lines={[
              'And somewhere between all those conversations,',
              'I stopped thinking of you as someone far away.',
              'You became someone close to my heart.',
            ]} />
            <Lines lines={[
              'Someone I could talk to about anything.',
              'Someone I could laugh with. Someone I could be angry with.',
              'Someone I could fight with. Someone I could miss.',
              "And someone I simply couldn't imagine losing.",
            ]} />
          </div>

          <Reveal delay={100}>
            <Quote>You came into my life as a stranger,<br />and somehow became my favorite person. 💕</Quote>
          </Reveal>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            <Lines lines={[
              "I don't know exactly when I fell for you.",
              'Maybe there was no single moment.',
              'Maybe it happened little by little...',
            ]} />
            <Lines lines={[
              'Every conversation. Every laugh. Every memory.',
              'Every fight that somehow ended with us finding our way back to each other.',
            ]} />
            <Lines lines={['You came into my life as a stranger...', 'And somehow became my favorite person.']} accent />
          </div>
          <Divider />
        </Container>
      </Section>

      {/* ── DISTANCE ────────────────────────────────────────────────────── */}
      <Section id="distance">
        <Container>
          <Reveal>
            <Eyebrow>Across Borders</Eyebrow>
            <H size={2}>Between India & Pakistan</H>
          </Reveal>

          <Reveal delay={150}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0, margin: '24px auto', width: 'fit-content' }}>
              <p style={{ fontSize: 26 }}>🇮🇳</p>
              <p style={{ fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', color: RG, fontFamily: 'Inter,sans-serif', margin: '4px 0 8px' }}>India</p>
              <div style={{ width: 1, height: 20, background: `${RG}77` }} />
              <div style={{ width: 1, height: 20, background: `${RG}44` }} />
              <p style={{ color: RG, fontSize: '1.1rem', margin: '2px 0' }}>×</p>
              <div style={{ width: 1, height: 20, background: `${RG}44` }} />
              <div style={{ width: 1, height: 20, background: `${RG}77` }} />
              <p style={{ fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', color: RG, fontFamily: 'Inter,sans-serif', margin: '8px 0 4px' }}>Pakistan</p>
              <p style={{ fontSize: 26 }}>🇵🇰</p>
            </div>
          </Reveal>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Lines lines={[
              'You were in Pakistan. I was in India.',
              'There was a distance between us that neither of us could simply ignore.',
              'But somehow, our hearts never felt that distance the same way.',
            ]} />
            <Lines lines={[
              'There was a border between our countries.',
              'But there was never a border between the feelings we had for each other. 🌹',
            ]} accent />
            <Lines lines={[
              'Maybe distance taught us to value every conversation.',
              'Every good morning. Every good night.',
              'Every "I miss you." Every moment we shared, even when we were apart.',
            ]} />
          </div>
          <Divider />
        </Container>
      </Section>

      {/* ── MEMORIES ────────────────────────────────────────────────────── */}
      <Section id="memories">
        <Container wide>
          <Reveal>
            <Eyebrow>Moments Of Us ✨</Eyebrow>
            <H size={2}>Moments Of Us</H>
            <P>Different moments. Different memories. One story.</P>
          </Reveal>

          <Reveal delay={150}>
            <div style={{ marginTop: 28, display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 12 }}>
              {memPhotos.map((src, i) => (
                <div key={i} onClick={() => openLB(memPhotos, i)}
                  style={{ border: `1px solid ${RG}33`, background: '#0B090A', cursor: 'pointer', transition: 'border-color 0.3s, box-shadow 0.3s' }}
                  onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = `${RG}99`; el.style.boxShadow = `0 0 20px ${RG}28` }}
                  onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = `${RG}33`; el.style.boxShadow = 'none' }}>
                  <img src={src} alt={`Memory ${i + 1}`} style={{ display: 'block', width: '100%', height: 'auto', objectFit: 'contain', background: '#0B090A' }} />
                </div>
              ))}
            </div>
          </Reveal>
          <Divider />
        </Container>
      </Section>

      {/* ── NOT PERFECT ─────────────────────────────────────────────────── */}
      <Section id="not-perfect">
        <Container>
          <Reveal>
            <Eyebrow>The Real Story</Eyebrow>
            <H size={2}>Our Love Isn't Perfect.</H>
          </Reveal>

          <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Lines lines={[
              "Our story isn't always a fairytale.",
              "We fight. A lot. 😅",
              "We get angry. We misunderstand each other.",
              "Sometimes our smallest problems become the biggest arguments.",
              "Sometimes we both want to be right.",
              "Sometimes we say things we don't really mean.",
            ]} />
            <Lines lines={[
              "But even after all of that...",
              "There is something that always brings us back.",
              "Us.",
            ]} accent />
            <Lines lines={[
              "Because no matter how angry we become... we still care.",
              "No matter how far apart we are... we still miss each other.",
              "And no matter how many times we fight...",
              "Neither of us truly wants to walk away.",
            ]} />
            <Lines lines={[
              "Maybe that's what makes our story special.",
              "Love isn't about never fighting.",
              "Maybe it's about choosing each other again...",
              "After every fight. Again. And again. And again.",
            ]} accent />
          </div>

          <Reveal delay={100}>
            <Quote>After every fight,<br />we still find our way back to each other. 🫶🏻</Quote>
          </Reveal>
          <Divider />
        </Container>
      </Section>

      {/* ── FUTURE WIFE ─────────────────────────────────────────────────── */}
      <Section id="future">
        <Container>
          <Reveal>
            <Eyebrow>Written For You</Eyebrow>
            <H size={2}>For My Future Wife...</H>
            <p style={{ textAlign: 'center', fontFamily: "'Cormorant Garamond',serif", color: RGL, fontSize: '1.1rem', fontStyle: 'italic', marginTop: 6 }}>
              Hafsa Ameer ❤️
            </p>
          </Reveal>

          <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Lines lines={[
              "Hafsa Ameer...",
              "You are not my wife today.",
              "But you are the person I hope, InshaAllah, to call my wife one day.",
            ]} accent />
            <Lines lines={[
              "The person whose hand I hope to hold.",
              "The person I hope to stand beside.",
              "The person I hope to build a beautiful future with.",
            ]} />
            <Lines lines={[
              "I don't know exactly what tomorrow will bring.",
              "I don't know what challenges life will put in front of us.",
              "But I know what I want.",
              "I want a future where you're still there.",
            ]} />
            <Lines lines={[
              "I want to see you smile.",
              "I want to make memories with you.",
              "And when life becomes difficult... I want us to face those days together.",
            ]} />
            <Lines lines={[
              "I don't want a perfect love story.",
              "I want our story.",
              "With all its happiness. With all its arguments.",
              "With all its laughter. With all its memories.",
              "Everything that makes us... Us. ❤️",
            ]} accent />
          </div>

          <Reveal delay={100}>
            <Quote>Maybe one day, we'll look back at 25 April 2025<br />and realize that our story was only just beginning.</Quote>
          </Reveal>
          <Divider />
        </Container>
      </Section>

      {/* ── IF I COULD GO BACK ──────────────────────────────────────────── */}
      <Section id="go-back">
        <Container>
          <Reveal>
            <Eyebrow>If I Could Go Back</Eyebrow>
            <H size={2}>If I Could Go Back...</H>
            <p style={{ textAlign: 'center', fontSize: 10, letterSpacing: '0.3em', textTransform: 'uppercase', color: RG, fontFamily: 'Inter,sans-serif', marginTop: 8 }}>
              25 April 2025
            </p>
          </Reveal>

          <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Lines lines={[
              "If I could go back to that exact day...",
              "Knowing everything I know today...",
              "Knowing all the conversations we'd have.",
              "Knowing all the laughs we'd share.",
              "Knowing all the fights we'd survive.",
              "Knowing all the memories we'd create.",
              "Knowing how much you would eventually mean to me...",
              "I would still do the exact same thing.",
            ]} />
          </div>

          <Reveal delay={200}>
            <div style={{ textAlign: 'center', margin: '36px 0 16px' }}>
              <p style={{
                fontFamily: "'Playfair Display',serif", color: WW, fontStyle: 'italic',
                fontSize: 'clamp(4rem,16vw,9rem)', lineHeight: 1,
                textShadow: `0 0 60px ${RG}55`,
              }}>"Hi."</p>
            </div>
            <P>Because that one little word brought you into my life.</P>
          </Reveal>

          <div style={{ marginTop: 20 }}>
            <Lines lines={[
              "And if I ever get the chance to choose you again...",
              "I will. Today. Tomorrow. And every day after that. 😘",
            ]} accent />
          </div>
          <Divider />
        </Container>
      </Section>

      {/* ── FINAL LOVE LETTER ───────────────────────────────────────────── */}
      <section id="final" style={{
        position: 'relative', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', textAlign: 'center',
        minHeight: '100vh', padding: '80px 24px', background: '#020202', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none',
          background: `radial-gradient(ellipse 75% 55% at 50% 50%, ${RG}18 0%, transparent 70%)`,
          animation: 'glow 9s ease-in-out infinite' }} />

        <div style={{ position: 'relative', zIndex: 1, maxWidth: 560, width: '100%', display: 'flex', flexDirection: 'column', gap: 20, alignItems: 'center' }}>
          <Reveal>
            <p style={{ fontFamily: "'Cormorant Garamond',serif", color: MUTED, fontSize: 'clamp(1.3rem,5vw,2rem)', fontStyle: 'italic' }}>
              Hafsa Ameer...
            </p>
          </Reveal>
          <Reveal delay={150}>
            <P>This is not the end of our story.</P>
          </Reveal>
          <Reveal delay={300}>
            <h2 style={{
              fontFamily: "'Playfair Display',serif", color: WW, fontWeight: 400,
              fontSize: 'clamp(2.2rem,9vw,5rem)', lineHeight: 1.15,
              textShadow: `0 0 80px ${RG}44`,
            }}>
              This is only<br />the beginning.
            </h2>
          </Reveal>

          <Reveal delay={500}>
            <div style={{ padding: '20px 28px', border: `1px solid ${RG}33`, width: '100%' }}>
              <p style={{ fontFamily: "'Playfair Display',serif", color: WW, fontSize: 'clamp(1rem,4vw,1.4rem)', marginBottom: 6 }}>
                Syed Mohi Alam ❤️ Hafsa Ameer
              </p>
              <p style={{ fontFamily: 'Inter,sans-serif', color: RG, fontSize: 11, letterSpacing: '0.18em', marginBottom: 14 }}>
                India 🇮🇳 × Pakistan 🇵🇰
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                <P>Two countries. Two hearts. One beautiful story.</P>
              </div>
            </div>
          </Reveal>

          <Reveal delay={700}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              <P>And InshaAllah...</P>
              <P italic accent>One beautiful future. ✨</P>
            </div>
          </Reveal>

          <Reveal delay={900}>
            <button onClick={() => scrollTo('hero')}
              style={{ padding: '12px 36px', border: `1px solid ${RG}`, color: RGL, background: 'transparent', fontFamily: 'Inter,sans-serif', fontSize: 10, letterSpacing: '0.25em', textTransform: 'uppercase', transition: 'background 0.4s', marginTop: 8 }}
              onMouseEnter={e => { (e.target as HTMLElement).style.background = `${RG}18` }}
              onMouseLeave={e => { (e.target as HTMLElement).style.background = 'transparent' }}>
              Start Our Story Again ♡
            </button>
          </Reveal>
        </div>
      </section>
    </div>
  )
}
